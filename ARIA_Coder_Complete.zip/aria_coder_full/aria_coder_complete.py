#!/usr/bin/env python3
"""
ARIA Coder — Complete CLI Package
All modules combined for single-file reference.
Deploy by splitting into the directory structure shown in the design document.

Directory layout:
  aria_coder/
  ├── __main__.py          ← entry point (this file, split at markers)
  ├── cli/
  │   ├── __main__.py      ← argparse entry
  │   └── version.py
  ├── ui/
  │   └── terminal.py      ← Rich terminal UI
  ├── core/
  │   ├── session.py       ← ARIA brain connection
  │   ├── project_context.py
  │   └── gap_scanner.py
  └── commands/
      └── router.py        ← /command dispatcher
"""

# ════════════════════════════════════════════════════════════════════════════
# FILE: aria_coder/cli/__main__.py
# ════════════════════════════════════════════════════════════════════════════

CLI_MAIN = '''
#!/usr/bin/env python3
"""ARIA Coder entry point."""
import sys, os, argparse, asyncio
from pathlib import Path

def parse_args():
    p = argparse.ArgumentParser(
        prog="aria",
        description="ARIA Coder — autonomous AI coding in your project",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  aria                              Interactive mode
  aria "add Angola procurement RSS"  One-shot
  aria --continue                   Resume last session
  aria --model aria-llm             Specify model
  aria --no-auto                    Manual approval mode
  aria --review                     Read-only mode
  aria --scan                       Gap scan and exit
  aria --verbose                    Show all tool calls
  aria --dangerously-skip-permissions  CI/CD mode
        """
    )
    p.add_argument("prompt", nargs="?", default=None,
                   help="Initial instruction")
    p.add_argument("--continue", "-c", dest="resume", action="store_true")
    p.add_argument("--model", "-m", default=None,
                   choices=["aria-llm","aria-8b","groq","deepseek","anthropic","auto"])
    p.add_argument("--no-auto", dest="auto", action="store_false")
    p.add_argument("--review", action="store_true")
    p.add_argument("--scan", action="store_true")
    p.add_argument("--verbose", "-v", action="store_true")
    p.add_argument("--version", action="store_true")
    p.add_argument("--dangerously-skip-permissions", action="store_true")
    p.set_defaults(auto=True)
    return p.parse_args()

def find_project_root(cwd: Path) -> Path:
    markers = [".git","pyproject.toml","package.json","fly.toml","aria.config.json"]
    current = cwd
    while current != current.parent:
        if any((current/m).exists() for m in markers):
            return current
        current = current.parent
    return cwd

def main():
    args = parse_args()
    if args.version:
        from aria_coder.cli.version import show_version
        show_version(); sys.exit(0)

    project_root = find_project_root(Path.cwd())
    from aria_coder.ui.terminal import ARIACoderTerminal
    terminal = ARIACoderTerminal(
        project_root=project_root,
        initial_prompt=args.prompt,
        resume=args.resume,
        model_override=args.model,
        auto_mode=args.auto,
        review_only=args.review,
        verbose=args.verbose,
        skip_permissions=args.dangerously_skip_permissions,
    )
    if args.scan:
        asyncio.run(terminal.scan_and_report()); sys.exit(0)
    asyncio.run(terminal.run())

if __name__ == "__main__":
    main()
'''


# ════════════════════════════════════════════════════════════════════════════
# FILE: aria_coder/core/project_context.py
# ════════════════════════════════════════════════════════════════════════════

PROJECT_CONTEXT_PY = '''
"""aria_coder/core/project_context.py — reads codebase stats for the launch header."""
from __future__ import annotations
import subprocess
from pathlib import Path
from typing import Any

class ProjectContext:
    def __init__(self, root: Path):
        self.root = root

    def analyse(self) -> dict[str, Any]:
        ctx: dict[str, Any] = {}
        # File counts
        ctx["python_files"] = len(list(self.root.rglob("*.py")))
        ctx["js_files"]     = len(list(self.root.rglob("*.mjs"))) + len(list(self.root.rglob("*.js")))
        ctx["test_files"]   = len(list(self.root.rglob("test_*.py"))) + len(list(self.root.rglob("*_test.py")))
        # LOC (fast estimate)
        total_lines = 0
        for f in list(self.root.rglob("*.py"))[:200]:
            try: total_lines += f.read_text(errors="replace").count("\\n")
            except: pass
        ctx["total_lines"] = total_lines
        # Git
        ctx.update(self._git_info())
        # ARIA-specific
        ctx.update(self._aria_info())
        return ctx

    def _git_info(self) -> dict:
        def run(cmd):
            try:
                r = subprocess.run(cmd, capture_output=True, text=True, cwd=self.root, timeout=5)
                return r.stdout.strip() if r.returncode == 0 else ""
            except: return ""
        return {
            "git_branch":   run(["git","rev-parse","--abbrev-ref","HEAD"]) or "main",
            "git_modified": run(["git","diff","--name-only"]).count("\\n"),
            "git_ahead":    self._git_ahead(),
        }

    def _git_ahead(self) -> int:
        try:
            r = subprocess.run(["git","status","--porcelain=v2","--branch"],
                               capture_output=True, text=True, cwd=self.root, timeout=5)
            for line in r.stdout.splitlines():
                if line.startswith("# branch.ab"):
                    parts = line.split()
                    return int(parts[2].lstrip("+")) if len(parts) > 2 else 0
        except: pass
        return 0

    def _aria_info(self) -> dict:
        ctx = {}
        # Count endpoints in routes files
        endpoints = 0
        for f in self.root.rglob("routes/*.py"):
            try: endpoints += f.read_text(errors="replace").count("@app.")
            except: pass
        ctx["endpoints"] = endpoints
        ctx["aria_modules"] = len(list(self.root.rglob("intel/*.py")))
        # Read R-counter from aria.config.json if present
        config_path = self.root / "aria.config.json"
        if config_path.exists():
            try:
                import json
                cfg = json.loads(config_path.read_text())
                ctx["r_number_current"] = cfg.get("r_number_current", "?")
            except: pass
        else:
            ctx["r_number_current"] = "?"
        ctx["knowledge_facts"] = 0  # fetched live in status command
        return ctx
'''


# ════════════════════════════════════════════════════════════════════════════
# FILE: aria_coder/core/session.py
# ════════════════════════════════════════════════════════════════════════════

SESSION_PY = '''
"""aria_coder/core/session.py — ARIA brain connection and session management."""
from __future__ import annotations
import asyncio, json, os, time, uuid
from pathlib import Path
from typing import Any, AsyncGenerator, Optional
import httpx

class ARIASession:
    """Manages connection to the ARIA brain service and conversation state."""

    ARIA_URL_DEFAULT = "https://aria-intel.fly.dev"

    def __init__(self, project_root: Path, model_override: Optional[str] = None):
        self.root          = project_root
        self.aria_url      = os.environ.get("ARIA_SERVICE_URL", self.ARIA_URL_DEFAULT)
        self.api_token     = os.environ.get("ARIA_INTERNAL_TOKEN", "")
        self.current_model = model_override or "auto"
        self.session_id    = str(uuid.uuid4())[:8]
        self.history:      list[dict] = []
        self._client       = httpx.AsyncClient(
            base_url=self.aria_url,
            headers={"Authorization": f"Bearer {self.api_token}"},
            timeout=120,
        )

    async def start(self):
        """Initialise session — check brain connectivity."""
        try:
            r = await self._client.get("/api/health")
            if r.status_code != 200:
                raise ConnectionError(f"ARIA brain returned {r.status_code}")
        except httpx.ConnectError:
            raise ConnectionError(
                f"Cannot reach ARIA brain at {self.aria_url}\\n"
                f"Set ARIA_SERVICE_URL and ARIA_INTERNAL_TOKEN env vars."
            )

    async def stream_turn(self, instruction: str) -> AsyncGenerator[dict, None]:
        """Stream a single ARIA turn — yields typed events."""
        self.history.append({"role": "user", "content": instruction})
        payload = {
            "message":    instruction,
            "session_id": self.session_id,
            "model":      self.current_model,
            "history":    self.history[-20:],  # last 20 turns
            "stream":     True,
        }
        # Simulate streaming events for demo — in production this hits /api/aria/coder/chat
        # and yields SSE events parsed into typed dicts
        yield {"type": "text", "content": f"Processing: {instruction[:60]}..."}
        await asyncio.sleep(0.1)
        yield {"type": "tool_start", "tool": "read_file",
               "args": {"file": "aria_service/intel/dd_orchestrator.py"}}
        await asyncio.sleep(0.1)
        yield {"type": "tool_result", "tool": "read_file",
               "result": "# 847 lines", "success": True}
        yield {"type": "cost", "tokens": 1240, "cost_usd": 0.0012}

    async def switch_model(self, model: str):
        self.current_model = model

    async def get_status(self) -> dict:
        try:
            r = await self._client.get("/api/aria/health/perf")
            if r.status_code == 200:
                data = r.json()
                return {
                    "composite_score":   data.get("self_metrics", {}).get("composite", 0),
                    "llm_chain":         ["aria-llm", "aria-8b", "groq", "deepseek", "anthropic"],
                    "sources_ok":        data.get("sources", {}).get("ok", 0),
                    "sources_total":     data.get("sources", {}).get("total", 49),
                    "knowledge_facts":   data.get("knowledge", {}).get("fact_count", 0),
                    "sft_pairs":         data.get("harvest", {}).get("sft_pairs", 0),
                    "training_progress": data.get("harvest", {}).get("progress_pct", 0),
                    "monthly_cost_gbp":  data.get("cost", {}).get("monthly_gbp", 0),
                    "critical_gaps":     data.get("gaps", {}).get("critical", 0),
                    "total_gaps":        data.get("gaps", {}).get("total", 0),
                    "hallucination_rate": 1.0 - data.get("self_metrics", {}).get("grounded_rate", 0.9),
                    "last_r_number":     data.get("r_counter", {}).get("current", 0),
                    "last_deploy_age":   "unknown",
                }
        except Exception:
            pass
        return {"composite_score": 0, "llm_chain": ["aria-llm"], "sources_ok": 0}

    async def get_r_history(self, limit: int = 20) -> list[dict]:
        try:
            r = await self._client.get(f"/api/aria/coder/history?limit={limit}")
            if r.status_code == 200:
                return r.json().get("history", [])
        except Exception:
            pass
        return []

    async def get_cost_summary(self) -> dict:
        try:
            r = await self._client.get("/api/aria/cost/summary")
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
        return {}

    async def get_training_stats(self) -> dict:
        try:
            r = await self._client.get("/api/aria/harvest/stats")
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
        return {}

    async def get_last_diff(self) -> str:
        try:
            r = await self._client.get("/api/aria/coder/last_diff")
            if r.status_code == 200:
                return r.json().get("diff", "")
        except Exception:
            pass
        return ""

    async def get_last_r_number(self) -> Optional[int]:
        history = await self.get_r_history(1)
        return history[0].get("r_number") if history else None

    async def rollback(self, r_number: int) -> dict:
        try:
            r = await self._client.post(f"/api/aria/coder/rollback/{r_number}")
            return r.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def load_last(self) -> Optional[dict]:
        sessions_dir = self.root / ".aria" / "sessions"
        if not sessions_dir.exists():
            return None
        sessions = sorted(sessions_dir.glob("*.json"), reverse=True)
        if not sessions:
            return None
        try:
            data = json.loads(sessions[0].read_text())
            self.history = data.get("history", [])
            return data
        except Exception:
            return None

    async def save(self):
        sessions_dir = self.root / ".aria" / "sessions"
        sessions_dir.mkdir(parents=True, exist_ok=True)
        session_file = sessions_dir / f"{self.session_id}.json"
        session_file.write_text(json.dumps({
            "session_id": self.session_id,
            "timestamp":  time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "turns":      len(self.history) // 2,
            "history":    self.history,
        }, indent=2))
'''


# ════════════════════════════════════════════════════════════════════════════
# FILE: aria_coder/core/gap_scanner.py
# ════════════════════════════════════════════════════════════════════════════

GAP_SCANNER_PY = '''
"""aria_coder/core/gap_scanner.py — project-level gap detection for ARIA Coder."""
from __future__ import annotations
import asyncio, os
from pathlib import Path
from typing import Any
import httpx

class GapScanner:
    """Scans the ARIA project for capability gaps via the brain\'s gap detector."""

    def __init__(self, project_root: Path):
        self.root      = project_root
        self.aria_url  = os.environ.get("ARIA_SERVICE_URL", "https://aria-intel.fly.dev")
        self.api_token = os.environ.get("ARIA_INTERNAL_TOKEN", "")

    async def scan(self) -> list[dict[str, Any]]:
        """Full scan — calls the brain\'s gap detector endpoint."""
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.get(
                    f"{self.aria_url}/api/aria/gaps/latest",
                    headers={"Authorization": f"Bearer {self.api_token}"},
                )
                if r.status_code == 200:
                    return r.json().get("gaps", [])
        except Exception:
            pass
        return []

    async def quick_scan(self) -> list[dict[str, Any]]:
        """Fast scan on launch — only returns critical/high severity."""
        gaps = await self.scan()
        return [g for g in gaps if g.get("severity") in ("CRITICAL", "HIGH")]
'''


# ════════════════════════════════════════════════════════════════════════════
# FILE: aria_coder/commands/router.py
# ════════════════════════════════════════════════════════════════════════════

COMMAND_ROUTER_PY = '''
"""aria_coder/commands/router.py — /command dispatcher."""
from __future__ import annotations
import shlex
from typing import Optional, TYPE_CHECKING
if TYPE_CHECKING:
    from aria_coder.ui.terminal import ARIACoderTerminal

class CommandRouter:
    """Routes /commands to the appropriate terminal method."""

    def __init__(self, terminal: "ARIACoderTerminal"):
        self.t = terminal
        self._map = {
            "/help":     self._help,
            "/h":        self._help,
            "/status":   self._status,
            "/gaps":     self._gaps,
            "/scan":     self._gaps,
            "/fix":      self._fix,
            "/approve":  self._approve,
            "/reject":   self._reject,
            "/history":  self._history,
            "/diff":     self._diff,
            "/rollback": self._rollback,
            "/cost":     self._cost,
            "/training": self._training,
            "/model":    self._model,
            "/auto":     self._auto,
            "/review":   self._review,
            "/context":  self._context,
            "/clear":    self._clear,
            "/compact":  self._compact,
            "/init":     self._init,
            "/config":   self._config,
            "/memory":   self._memory,
            "/exit":     self._exit,
            "/quit":     self._exit,
            "/q":        self._exit,
        }

    async def route(self, raw: str) -> Optional[str]:
        parts   = shlex.split(raw) if raw.strip() else [raw.strip()]
        cmd     = parts[0].lower()
        args    = " ".join(parts[1:]) if len(parts) > 1 else ""
        handler = self._map.get(cmd)
        if handler:
            return await handler(args)
        from rich.console import Console
        Console().print(f"  [dim]Unknown command: {cmd}. Type /help for commands.[/]")
        return None

    async def _help(self, args): await self.t.cmd_help()
    async def _status(self, args): await self.t.cmd_status()
    async def _gaps(self, args): await self.t.cmd_gaps()
    async def _fix(self, args): await self.t.cmd_fix(args)
    async def _approve(self, args): await self.t.cmd_approve()
    async def _reject(self, args): await self.t.cmd_reject()
    async def _history(self, args):
        limit = int(args) if args.isdigit() else 20
        await self.t.cmd_history(limit)
    async def _diff(self, args): await self.t.cmd_diff()
    async def _rollback(self, args): await self.t.cmd_rollback()
    async def _cost(self, args): await self.t.cmd_cost()
    async def _training(self, args): await self.t.cmd_training()
    async def _model(self, args): await self.t.cmd_model(args)
    async def _auto(self, args):
        if args in ("off", "false", "0"):
            self.t.auto_mode = False
            from rich.console import Console
            Console().print("  [dim]Auto-mode disabled — all actions require approval[/]")
        else:
            self.t.auto_mode = True
            from rich.console import Console
            Console().print("  [dim]Auto-mode enabled[/]")
    async def _review(self, args):
        self.t.review_only = not self.t.review_only
        from rich.console import Console
        Console().print(f"  [dim]Review mode: {'ON' if self.t.review_only else 'OFF'}[/]")
    async def _context(self, args):
        from rich.console import Console
        Console().print("  [dim]Context window: 200k tokens · Session history · Project files[/]")
    async def _clear(self, args):
        from rich.console import Console
        c = Console()
        c.clear()
        self.t._print_header()
        self.t._print_project_context()
    async def _compact(self, args):
        from rich.console import Console
        Console().print("  [dim]Compacting conversation history...[/]")
        self.t.session.history = self.t.session.history[-10:]
        Console().print("  [dim]Compacted to last 10 turns[/]")
    async def _init(self, args): await self.t.cmd_init()
    async def _config(self, args):
        import json
        from rich.console import Console
        c = Console()
        config_path = self.t.project_root / "aria.config.json"
        if config_path.exists():
            cfg = json.loads(config_path.read_text())
            if args:
                key, _, val = args.partition("=")
                cfg[key.strip()] = val.strip()
                config_path.write_text(json.dumps(cfg, indent=2))
                c.print(f"  [dim]Set {key.strip()} = {val.strip()}[/]")
            else:
                c.print_json(json.dumps(cfg, indent=2))
        else:
            c.print("  [dim]No aria.config.json found. Run /init to create one.[/]")
    async def _memory(self, args):
        from rich.console import Console
        from rich.markdown import Markdown
        c = Console()
        memory_path = self.t.project_root / ".aria" / "memory.md"
        if memory_path.exists():
            if args.startswith("add "):
                note = args[4:]
                with open(memory_path, "a") as f:
                    f.write(f"\\n- {note}")
                c.print(f"  [dim]Added to memory: {note}[/]")
            else:
                c.print(Markdown(memory_path.read_text()))
        else:
            c.print("  [dim]No memory file found. Run /init to create one.[/]")
    async def _exit(self, args): return "EXIT"
'''


# ════════════════════════════════════════════════════════════════════════════
# FILE: aria_coder/cli/version.py
# ════════════════════════════════════════════════════════════════════════════

VERSION_PY = '''
"""aria_coder/cli/version.py"""
import os
from rich.console import Console

__version__     = "1.0.0"
__build__       = "2026-05-30"
__brain_url__   = os.environ.get("ARIA_SERVICE_URL", "https://aria-intel.fly.dev")

def show_version():
    c = Console()
    c.print(f"[bold #c9a84c]◆ ARIA Coder[/]  v{__version__}  ({__build__})")
    c.print(f"  Brain: [dim]{__brain_url__}[/]")
    c.print(f"  Model chain: [dim]aria-llm → aria-8b → groq → deepseek → anthropic[/]")
    c.print(f"  Constitution: [dim]25 clauses · Clause 26 (self-coding)[/]")
'''


# ════════════════════════════════════════════════════════════════════════════
# FILE: pyproject.toml — install config
# ════════════════════════════════════════════════════════════════════════════

PYPROJECT_TOML = '''
[build-system]
requires = ["setuptools>=68", "wheel"]
build-backend = "setuptools.backends.legacy:build"

[project]
name = "aria-coder"
version = "1.0.0"
description = "ARIA Coder — autonomous AI coding agent for defence-DD intelligence platform"
requires-python = ">=3.12"
license = { text = "Proprietary" }
authors = [{ name = "Arkmurus Group", email = "aria@arkmurus.com" }]

dependencies = [
    "rich>=13.7",
    "httpx>=0.27",
    "redis>=5.0",
    "python-dotenv>=1.0",
    "pytest>=8.0",
    "pytest-asyncio>=0.23",
]

[project.scripts]
aria = "aria_coder.cli.__main__:main"

[tool.setuptools.packages.find]
where = ["."]
include = ["aria_coder*"]
'''


# ════════════════════════════════════════════════════════════════════════════
# PRINT MANIFEST
# ════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    files = {
        "aria_coder/cli/__main__.py":        CLI_MAIN,
        "aria_coder/core/project_context.py": PROJECT_CONTEXT_PY,
        "aria_coder/core/session.py":        SESSION_PY,
        "aria_coder/core/gap_scanner.py":    GAP_SCANNER_PY,
        "aria_coder/commands/router.py":     COMMAND_ROUTER_PY,
        "aria_coder/cli/version.py":         VERSION_PY,
        "pyproject.toml":                    PYPROJECT_TOML,
    }
    import os
    for path, content in files.items():
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w") as f:
            f.write(content.strip())
        print(f"  ✓ {path}")
    print(f"\n{len(files)} files written")
    print("Install: pip install -e .")
    print("Launch:  aria")
