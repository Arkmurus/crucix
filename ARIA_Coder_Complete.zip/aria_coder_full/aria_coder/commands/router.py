"""aria_coder/commands/router.py — /command dispatcher."""
from __future__ import annotations
import shlex
from typing import Optional, TYPE_CHECKING
if TYPE_CHECKING:
    from aria_coder.ui.terminal import ARIACoderTerminal

class CommandRouter:
    """Routes /commands to the appropriate terminal method."""

    def __init__(self, terminal: "ARIACoderTerminal"):
        self.t = terminal
        self._map = {
            "/help":     self._help,
            "/h":        self._help,
            "/status":   self._status,
            "/gaps":     self._gaps,
            "/scan":     self._gaps,
            "/fix":      self._fix,
            "/approve":  self._approve,
            "/reject":   self._reject,
            "/history":  self._history,
            "/diff":     self._diff,
            "/rollback": self._rollback,
            "/cost":     self._cost,
            "/training": self._training,
            "/model":    self._model,
            "/auto":     self._auto,
            "/review":   self._review,
            "/context":  self._context,
            "/clear":    self._clear,
            "/compact":  self._compact,
            "/init":     self._init,
            "/config":   self._config,
            "/memory":   self._memory,
            "/exit":     self._exit,
            "/quit":     self._exit,
            "/q":        self._exit,
        }

    async def route(self, raw: str) -> Optional[str]:
        parts   = shlex.split(raw) if raw.strip() else [raw.strip()]
        cmd     = parts[0].lower()
        args    = " ".join(parts[1:]) if len(parts) > 1 else ""
        handler = self._map.get(cmd)
        if handler:
            return await handler(args)
        from rich.console import Console
        Console().print(f"  [dim]Unknown command: {cmd}. Type /help for commands.[/]")
        return None

    async def _help(self, args): await self.t.cmd_help()
    async def _status(self, args): await self.t.cmd_status()
    async def _gaps(self, args): await self.t.cmd_gaps()
    async def _fix(self, args): await self.t.cmd_fix(args)
    async def _approve(self, args): await self.t.cmd_approve()
    async def _reject(self, args): await self.t.cmd_reject()
    async def _history(self, args):
        limit = int(args) if args.isdigit() else 20
        await self.t.cmd_history(limit)
    async def _diff(self, args): await self.t.cmd_diff()
    async def _rollback(self, args): await self.t.cmd_rollback()
    async def _cost(self, args): await self.t.cmd_cost()
    async def _training(self, args): await self.t.cmd_training()
    async def _model(self, args): await self.t.cmd_model(args)
    async def _auto(self, args):
        if args in ("off", "false", "0"):
            self.t.auto_mode = False
            from rich.console import Console
            Console().print("  [dim]Auto-mode disabled — all actions require approval[/]")
        else:
            self.t.auto_mode = True
            from rich.console import Console
            Console().print("  [dim]Auto-mode enabled[/]")
    async def _review(self, args):
        self.t.review_only = not self.t.review_only
        from rich.console import Console
        Console().print(f"  [dim]Review mode: {'ON' if self.t.review_only else 'OFF'}[/]")
    async def _context(self, args):
        from rich.console import Console
        Console().print("  [dim]Context window: 200k tokens · Session history · Project files[/]")
    async def _clear(self, args):
        from rich.console import Console
        c = Console()
        c.clear()
        self.t._print_header()
        self.t._print_project_context()
    async def _compact(self, args):
        from rich.console import Console
        Console().print("  [dim]Compacting conversation history...[/]")
        self.t.session.history = self.t.session.history[-10:]
        Console().print("  [dim]Compacted to last 10 turns[/]")
    async def _init(self, args): await self.t.cmd_init()
    async def _config(self, args):
        import json
        from rich.console import Console
        c = Console()
        config_path = self.t.project_root / "aria.config.json"
        if config_path.exists():
            cfg = json.loads(config_path.read_text())
            if args:
                key, _, val = args.partition("=")
                cfg[key.strip()] = val.strip()
                config_path.write_text(json.dumps(cfg, indent=2))
                c.print(f"  [dim]Set {key.strip()} = {val.strip()}[/]")
            else:
                c.print_json(json.dumps(cfg, indent=2))
        else:
            c.print("  [dim]No aria.config.json found. Run /init to create one.[/]")
    async def _memory(self, args):
        from rich.console import Console
        from rich.markdown import Markdown
        c = Console()
        memory_path = self.t.project_root / ".aria" / "memory.md"
        if memory_path.exists():
            if args.startswith("add "):
                note = args[4:]
                with open(memory_path, "a") as f:
                    f.write(f"\n- {note}")
                c.print(f"  [dim]Added to memory: {note}[/]")
            else:
                c.print(Markdown(memory_path.read_text()))
        else:
            c.print("  [dim]No memory file found. Run /init to create one.[/]")
    async def _exit(self, args): return "EXIT"