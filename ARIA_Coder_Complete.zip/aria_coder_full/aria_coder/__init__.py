"""ARIA Coder — Autonomous Intelligence Coding Agent v1.0.0"""
__version__ = "1.0.0"
