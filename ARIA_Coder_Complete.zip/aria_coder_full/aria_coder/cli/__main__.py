#!/usr/bin/env python3
"""ARIA Coder entry point."""
import sys, os, argparse, asyncio
from pathlib import Path

def parse_args():
    p = argparse.ArgumentParser(
        prog="aria",
        description="ARIA Coder — autonomous AI coding in your project",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  aria                              Interactive mode
  aria "add Angola procurement RSS"  One-shot
  aria --continue                   Resume last session
  aria --model aria-llm             Specify model
  aria --no-auto                    Manual approval mode
  aria --review                     Read-only mode
  aria --scan                       Gap scan and exit
  aria --verbose                    Show all tool calls
  aria --dangerously-skip-permissions  CI/CD mode
        """
    )
    p.add_argument("prompt", nargs="?", default=None,
                   help="Initial instruction")
    p.add_argument("--continue", "-c", dest="resume", action="store_true")
    p.add_argument("--model", "-m", default=None,
                   choices=["aria-llm","aria-8b","groq","deepseek","anthropic","auto"])
    p.add_argument("--no-auto", dest="auto", action="store_false")
    p.add_argument("--review", action="store_true")
    p.add_argument("--scan", action="store_true")
    p.add_argument("--verbose", "-v", action="store_true")
    p.add_argument("--version", action="store_true")
    p.add_argument("--dangerously-skip-permissions", action="store_true")
    p.set_defaults(auto=True)
    return p.parse_args()

def find_project_root(cwd: Path) -> Path:
    markers = [".git","pyproject.toml","package.json","fly.toml","aria.config.json"]
    current = cwd
    while current != current.parent:
        if any((current/m).exists() for m in markers):
            return current
        current = current.parent
    return cwd

def main():
    args = parse_args()
    if args.version:
        from aria_coder.cli.version import show_version
        show_version(); sys.exit(0)

    project_root = find_project_root(Path.cwd())
    from aria_coder.ui.terminal import ARIACoderTerminal
    terminal = ARIACoderTerminal(
        project_root=project_root,
        initial_prompt=args.prompt,
        resume=args.resume,
        model_override=args.model,
        auto_mode=args.auto,
        review_only=args.review,
        verbose=args.verbose,
        skip_permissions=args.dangerously_skip_permissions,
    )
    if args.scan:
        asyncio.run(terminal.scan_and_report()); sys.exit(0)
    asyncio.run(terminal.run())

if __name__ == "__main__":
    main()