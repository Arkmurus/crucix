"""aria_coder/cli/version.py"""
import os
from rich.console import Console

__version__     = "1.0.0"
__build__       = "2026-05-30"
__brain_url__   = os.environ.get("ARIA_SERVICE_URL", "https://aria-intel.fly.dev")

def show_version():
    c = Console()
    c.print(f"[bold #c9a84c]◆ ARIA Coder[/]  v{__version__}  ({__build__})")
    c.print(f"  Brain: [dim]{__brain_url__}[/]")
    c.print(f"  Model chain: [dim]aria-llm → aria-8b → groq → deepseek → anthropic[/]")
    c.print(f"  Constitution: [dim]25 clauses · Clause 26 (self-coding)[/]")