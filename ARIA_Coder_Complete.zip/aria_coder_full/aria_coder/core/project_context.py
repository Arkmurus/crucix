"""aria_coder/core/project_context.py — reads codebase stats for the launch header."""
from __future__ import annotations
import subprocess
from pathlib import Path
from typing import Any

class ProjectContext:
    def __init__(self, root: Path):
        self.root = root

    def analyse(self) -> dict[str, Any]:
        ctx: dict[str, Any] = {}
        # File counts
        ctx["python_files"] = len(list(self.root.rglob("*.py")))
        ctx["js_files"]     = len(list(self.root.rglob("*.mjs"))) + len(list(self.root.rglob("*.js")))
        ctx["test_files"]   = len(list(self.root.rglob("test_*.py"))) + len(list(self.root.rglob("*_test.py")))
        # LOC (fast estimate)
        total_lines = 0
        for f in list(self.root.rglob("*.py"))[:200]:
            try: total_lines += f.read_text(errors="replace").count("\n")
            except: pass
        ctx["total_lines"] = total_lines
        # Git
        ctx.update(self._git_info())
        # ARIA-specific
        ctx.update(self._aria_info())
        return ctx

    def _git_info(self) -> dict:
        def run(cmd):
            try:
                r = subprocess.run(cmd, capture_output=True, text=True, cwd=self.root, timeout=5)
                return r.stdout.strip() if r.returncode == 0 else ""
            except: return ""
        return {
            "git_branch":   run(["git","rev-parse","--abbrev-ref","HEAD"]) or "main",
            "git_modified": run(["git","diff","--name-only"]).count("\n"),
            "git_ahead":    self._git_ahead(),
        }

    def _git_ahead(self) -> int:
        try:
            r = subprocess.run(["git","status","--porcelain=v2","--branch"],
                               capture_output=True, text=True, cwd=self.root, timeout=5)
            for line in r.stdout.splitlines():
                if line.startswith("# branch.ab"):
                    parts = line.split()
                    return int(parts[2].lstrip("+")) if len(parts) > 2 else 0
        except: pass
        return 0

    def _aria_info(self) -> dict:
        ctx = {}
        # Count endpoints in routes files
        endpoints = 0
        for f in self.root.rglob("routes/*.py"):
            try: endpoints += f.read_text(errors="replace").count("@app.")
            except: pass
        ctx["endpoints"] = endpoints
        ctx["aria_modules"] = len(list(self.root.rglob("intel/*.py")))
        # Read R-counter from aria.config.json if present
        config_path = self.root / "aria.config.json"
        if config_path.exists():
            try:
                import json
                cfg = json.loads(config_path.read_text())
                ctx["r_number_current"] = cfg.get("r_number_current", "?")
            except: pass
        else:
            ctx["r_number_current"] = "?"
        ctx["knowledge_facts"] = 0  # fetched live in status command
        return ctx