"""aria_coder/core/gap_scanner.py — project-level gap detection for ARIA Coder."""
from __future__ import annotations
import asyncio, os
from pathlib import Path
from typing import Any
import httpx

class GapScanner:
    """Scans the ARIA project for capability gaps via the brain's gap detector."""

    def __init__(self, project_root: Path):
        self.root      = project_root
        self.aria_url  = os.environ.get("ARIA_SERVICE_URL", "https://aria-intel.fly.dev")
        self.api_token = os.environ.get("ARIA_INTERNAL_TOKEN", "")

    async def scan(self) -> list[dict[str, Any]]:
        """Full scan — calls the brain's gap detector endpoint."""
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.get(
                    f"{self.aria_url}/api/aria/gaps/latest",
                    headers={"Authorization": f"Bearer {self.api_token}"},
                )
                if r.status_code == 200:
                    return r.json().get("gaps", [])
        except Exception:
            pass
        return []

    async def quick_scan(self) -> list[dict[str, Any]]:
        """Fast scan on launch — only returns critical/high severity."""
        gaps = await self.scan()
        return [g for g in gaps if g.get("severity") in ("CRITICAL", "HIGH")]