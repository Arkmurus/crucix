"""aria_coder/core/session.py — ARIA brain connection and session management."""
from __future__ import annotations
import asyncio, json, os, time, uuid
from pathlib import Path
from typing import Any, AsyncGenerator, Optional
import httpx

class ARIASession:
    """Manages connection to the ARIA brain service and conversation state."""

    ARIA_URL_DEFAULT = "https://aria-intel.fly.dev"

    def __init__(self, project_root: Path, model_override: Optional[str] = None):
        self.root          = project_root
        self.aria_url      = os.environ.get("ARIA_SERVICE_URL", self.ARIA_URL_DEFAULT)
        self.api_token     = os.environ.get("ARIA_INTERNAL_TOKEN", "")
        self.current_model = model_override or "auto"
        self.session_id    = str(uuid.uuid4())[:8]
        self.history:      list[dict] = []
        self._client       = httpx.AsyncClient(
            base_url=self.aria_url,
            headers={"Authorization": f"Bearer {self.api_token}"},
            timeout=120,
        )

    async def start(self):
        """Initialise session — check brain connectivity."""
        try:
            r = await self._client.get("/api/health")
            if r.status_code != 200:
                raise ConnectionError(f"ARIA brain returned {r.status_code}")
        except httpx.ConnectError:
            raise ConnectionError(
                f"Cannot reach ARIA brain at {self.aria_url}\n"
                f"Set ARIA_SERVICE_URL and ARIA_INTERNAL_TOKEN env vars."
            )

    async def stream_turn(self, instruction: str) -> AsyncGenerator[dict, None]:
        """Stream a single ARIA turn — yields typed events."""
        self.history.append({"role": "user", "content": instruction})
        payload = {
            "message":    instruction,
            "session_id": self.session_id,
            "model":      self.current_model,
            "history":    self.history[-20:],  # last 20 turns
            "stream":     True,
        }
        # Simulate streaming events for demo — in production this hits /api/aria/coder/chat
        # and yields SSE events parsed into typed dicts
        yield {"type": "text", "content": f"Processing: {instruction[:60]}..."}
        await asyncio.sleep(0.1)
        yield {"type": "tool_start", "tool": "read_file",
               "args": {"file": "aria_service/intel/dd_orchestrator.py"}}
        await asyncio.sleep(0.1)
        yield {"type": "tool_result", "tool": "read_file",
               "result": "# 847 lines", "success": True}
        yield {"type": "cost", "tokens": 1240, "cost_usd": 0.0012}

    async def switch_model(self, model: str):
        self.current_model = model

    async def get_status(self) -> dict:
        try:
            r = await self._client.get("/api/aria/health/perf")
            if r.status_code == 200:
                data = r.json()
                return {
                    "composite_score":   data.get("self_metrics", {}).get("composite", 0),
                    "llm_chain":         ["aria-llm", "aria-8b", "groq", "deepseek", "anthropic"],
                    "sources_ok":        data.get("sources", {}).get("ok", 0),
                    "sources_total":     data.get("sources", {}).get("total", 49),
                    "knowledge_facts":   data.get("knowledge", {}).get("fact_count", 0),
                    "sft_pairs":         data.get("harvest", {}).get("sft_pairs", 0),
                    "training_progress": data.get("harvest", {}).get("progress_pct", 0),
                    "monthly_cost_gbp":  data.get("cost", {}).get("monthly_gbp", 0),
                    "critical_gaps":     data.get("gaps", {}).get("critical", 0),
                    "total_gaps":        data.get("gaps", {}).get("total", 0),
                    "hallucination_rate": 1.0 - data.get("self_metrics", {}).get("grounded_rate", 0.9),
                    "last_r_number":     data.get("r_counter", {}).get("current", 0),
                    "last_deploy_age":   "unknown",
                }
        except Exception:
            pass
        return {"composite_score": 0, "llm_chain": ["aria-llm"], "sources_ok": 0}

    async def get_r_history(self, limit: int = 20) -> list[dict]:
        try:
            r = await self._client.get(f"/api/aria/coder/history?limit={limit}")
            if r.status_code == 200:
                return r.json().get("history", [])
        except Exception:
            pass
        return []

    async def get_cost_summary(self) -> dict:
        try:
            r = await self._client.get("/api/aria/cost/summary")
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
        return {}

    async def get_training_stats(self) -> dict:
        try:
            r = await self._client.get("/api/aria/harvest/stats")
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
        return {}

    async def get_last_diff(self) -> str:
        try:
            r = await self._client.get("/api/aria/coder/last_diff")
            if r.status_code == 200:
                return r.json().get("diff", "")
        except Exception:
            pass
        return ""

    async def get_last_r_number(self) -> Optional[int]:
        history = await self.get_r_history(1)
        return history[0].get("r_number") if history else None

    async def rollback(self, r_number: int) -> dict:
        try:
            r = await self._client.post(f"/api/aria/coder/rollback/{r_number}")
            return r.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def load_last(self) -> Optional[dict]:
        sessions_dir = self.root / ".aria" / "sessions"
        if not sessions_dir.exists():
            return None
        sessions = sorted(sessions_dir.glob("*.json"), reverse=True)
        if not sessions:
            return None
        try:
            data = json.loads(sessions[0].read_text())
            self.history = data.get("history", [])
            return data
        except Exception:
            return None

    async def save(self):
        sessions_dir = self.root / ".aria" / "sessions"
        sessions_dir.mkdir(parents=True, exist_ok=True)
        session_file = sessions_dir / f"{self.session_id}.json"
        session_file.write_text(json.dumps({
            "session_id": self.session_id,
            "timestamp":  time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "turns":      len(self.history) // 2,
            "history":    self.history,
        }, indent=2))